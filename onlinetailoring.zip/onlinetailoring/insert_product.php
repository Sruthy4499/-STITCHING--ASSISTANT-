<?php
session_start();
include('connection.php');
$id = $_SESSION['fid'];
$sql = mysqli_query($con,"SELECT * from `login` where loginid='$id'");
$iid=0;
@$iid = $_GET['fid'];
while($row=mysqli_fetch_array($sql)){
  $name = $row['loginid'];
 
}


if(isset($_POST['submit']))
{
	$category=$_POST['category'];
	$product=$_POST['products'];
	
	$productprice=$_POST['price'];
	$quantity=$_POST['quantity'];
	$image=$_FILES["image"]["name"];
	$uid='$id';
    
 
  
//for getting product id
  
move_uploaded_file($_FILES["image"]["tmp_name"],"images".$_FILES["image"]["name"]);	
$sql=mysqli_query($con,"insert into cart_product(stitichingid,products,price,quantity,image,status) values('$name','$product','$productprice','$quantity','$image',1)");

   

}
?>

                           
                          
    


<!DOCTYPE html>

<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">
    <link rel="shortcut icon" href="img/vismaya.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="img/vismaya.png">

    <!-- Title Page-->
    <title>Vismaya</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i"
        rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- Main CSS-->
    <link href="css_insert/main.css" rel="stylesheet" media="all">

</head>

<body>
    <?php
    include 'header.php'
    ?>
    
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50" style="background-color: #f5f5f5;">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading" style="background-color: #82ae46;">
                    <h2 class="title">ADD PRODUCTS</h2>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        
                       <div class="form-row">
                            <div class="name">Category</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <?php if($iid==0){ ?>
                                            <select name="category" id="category-dropdown" onchange="location = this.value;">
                                            <option value="">Select Category</option>
                                            <?php $query=mysqli_query($con,"select * from tbl_category");
                                          while($row=mysqli_fetch_array($query))
                                          {?>

                                            <option value="insert_product.php?sid=<?php echo $row['id'];?>"> <?php echo $row['categoryname'];?>
                                            </option>
                                            <?php } ?>
                                        </select>
                                            <?php }else{ ?>
                                            <select name="category" id="category-dropdown" onchange="location = this.value;">
                                            <?php $query=mysqli_query($con,"select * from tbl_category");
                                          while($row=mysqli_fetch_array($query))
                                          {?>

                                            <option value="insert_product.php?sid=<?php echo $row['id'];?>" <?php if($row['id']==$iid){?>selected<?php }?>> <?php echo $row['categoryname'];?>
                                            </option>
                                            <?php } ?>
                                        </select>
                                            <?php } ?>
                                       
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
						
				
					   
					   
                        <div class="form-row">
                            <div class="name">Products</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="products"  id = "product-dropdown" >
                                      <option value="">Select Products</option>
										<?php
										$result = mysqli_query($con,"SELECT * FROM tbl_products WHERE category = '$iid'");
										while($row = mysqli_fetch_array($result)) {
										?>
										<option value="<?php echo $row["pro_id"];?>"><?php echo $row["product_name"];?></option>
										<?php
										}
										?>
                                            
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
						
						 <div class="form-row">
                            <div class="name">Product Images</div>
						 <input type="file" class="form-control" name="image" id="image">
                    </div>
						
						
						
						
                        <div class="form-row">
                            <div class="name">Price</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="price">

                                </div>
                            </div>
                        </div>
						 <div class="form-row">
                            <div class="name">Quantity(in kgs)</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="quantity">

                                </div>
                            </div>
                        </div>
                        
                        
                      




                        <div>
                            <button class="btn btn--radius-2 btn--red" type="submit" name="submit" style="background-color:#d33b33">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	
	<!--<section class="grids-section bd-content">

                <!-- Grids Info -->
                <!--<div class="outer-w3-agile mt-2">
                    <h4 class="tittle-w3-agileits mb-4">ADDED PRODUCTS</h4>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Category</th>
								<th>Product</th>
								 <th>Image</th>
								 <th>Price</th>
								 <th>Quantity(in Kg)</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                           
                          <?php
						include 'connection.php';
$sql="select tbl_products.product_name, farmer_product.image, tbl_category.categoryname,farmer_product.price, farmer_product.quantity from farmer_product join tbl_products 
    on tbl_products.pro_id = farmer_product.products join tbl_category on tbl_category.id=tbl_products.category";
$result = mysqli_query($con, $sql);

while($r=mysqli_fetch_array($result))
{?>
		<tr><td><?php echo $r['categoryname'];?></td>
		    <td><?php echo $r['product_name'];?></td>
			<td><img src="images/<?php echo $r['image'];?>" width="100" height="100"></td>
			<td><?php echo $r['price'];?></td>
			<td><?php echo $r['quantity'];?></td>
		  
        
      
               
                      <?php
}
?></tbody>
                    </table>
                </div>-->
	
	

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>
	

	
	

</body>

</html>