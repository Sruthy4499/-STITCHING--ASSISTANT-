<?php 
require_once "connection.php";
if(isset($_POST['insert'])){

    $leave_type=$_POST['leave_type'];
    $day_type = $_POST['day_type'];
    $date_start=$_POST['date_start'];
    $date_end= $_POST['date_end'];
    $reason= $_POST['reason'];
    $applied_on=$_POST['applied_on'];
    $reason= $_POST['reason'];
    $is_approved=$_POST['is_approved'];
    
   

  
  $sql=mysqli_query($con,"INSERT INTO `leave_add`(  `leave_type`,`day_type`,`date_start`,`date_end`,`applied_on`,`reason`,`is_approved`)values('$leave_type','$day_type','$date_start','$date_end','$applied','$reason','$NO')") or die(mysqli_error($con));
  if($sql)
    echo "<script>alert('Inserted Successfully');</script>";
}
if(isset($_POST['back']))
{

  header('location:staff_index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Vismaya</title>


    <!-- Main CSS-->
     <!-- Template Stylesheet -->
     <link href="css/style3.css" rel="stylesheet">

</head>
<body>
<section>
   
  <div class="container">
    <div class="title"><b>Add Leave<b></div>
    <br />
    <div class="content">
      <form action="" method="post" enctype="multipart/form-data">
        <div class="user-details">
        <div class="input-box">
            <span class="details">Leave Type</span>
            <select name='leave_type'> 
            <option value="Select">Select</option> 
                                <option value="Casual Leave">Casual Leave</option>  
                                <option value="Sick Leave">Sick Leave </option>  
                                <option value="Maternity Leave">Maternity Leave </option>  
                                <option value="Marriage Leave">Marriage Leave </option>
                                <option value="Vacation Leave">Vacation Leave </option>
                                     </select> 
                                  <br><br>
          </div>   
          <div class="input-box">
            <span class="details">Day_type</span>
            <select name='day_type'> 
            <option value="Select">Select</option> 
                                <option value="Whole Day">Whole Day</option>  
                                <option value="Half Day">Half Day </option>  
                                     </select> 
                                  <br><br>
</div>
<div class="input-box">
            <span class="details">Date Start</span>
            <input type="date" name="date_start" value="<?php echo isset($_POST['date_start']) ? htmlspecialchars($_POST['date_start'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Date End</span>
            <input type="date" name="date_end" value="<?php echo isset($_POST['date_end']) ? htmlspecialchars($_POST['date_end'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Days</span>
            <input type="text" name="days" value="<?php echo isset($_POST['days']) ? htmlspecialchars($_POST['days'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Reason</span>
            <input type="text" name="reason" value="<?php echo isset($_POST['reason']) ? htmlspecialchars($_POST['reason'],ENT_QUOTES): '';?>">  
          </div>

          
          <input type="submit" name="insert" value="Insert" class="btn btn-primary" style="margin-left: 70%;">
          <button type="submit" name="back"  style="align:right;">Go back!</button>

      </form>
    </div>
  </div>
    </section>

</body>
</html>
    
    
    