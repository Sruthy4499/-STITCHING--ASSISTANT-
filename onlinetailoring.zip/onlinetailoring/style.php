<?php
require_once "connection.php";
if(isset($_POST['order'])){

    
    $style_name = $_POST['style_name'];
    $lining=$_POST['lining'];
    $delivery_date = $_POST['delivery_date'];
	

    $filepath1=pathinfo($_FILES['image']['name']) ;
    $extension1=$filepath1['extension'];
    $rd=  rand();
    $aname= $rd.'.'.$extension1;
    $pathinfo='uploads/'.$aname;
    move_uploaded_file($_FILES['image']['tmp_name'],$pathinfo);
   
  $sql=mysqli_query($con,"INSERT INTO `style`( `style_name`, `lining`, `delivery_date`,`image`)values('$style_name','$lining','$delivery_date','$aname')") or die(mysqli_error($con));
  if($sql)
    echo "<script>alert('Ordered Successfully');</script>";
}
if(isset($_POST['back']))
{

  header('location:user_index.php');
}
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Vismaya</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
    
    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style3.css" rel="stylesheet">

    <script>
    var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".gif", ".png"];    
    function ValidateSingleInput(oInput) {
      if (oInput.type == "file") {
          var sFileName = oInput.value;
          if (sFileName.length > 0) {
              var blnValid = false;
              for (var j = 0; j < _validFileExtensions.length; j++) {
                  var sCurExtension = _validFileExtensions[j];
                  if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                      blnValid = true;
                      break;
                  }
              }
              
              if (!blnValid) {
                  alert("Sorry, file is invalid, allowed extensions are: " + _validFileExtensions.join(", "));
                  oInput.value = "";
                  return false;
              }
          }
      }
      return true;
    }

	

    </script>
  </head>
  
    <section>
    <body background="img/bg.jpg">
  <div class="container">
    <div class="title"><b>Style<b></div>
    <br />
    <div class="content">
      <form action="" method="post" enctype="multipart/form-data">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Style Name</span>
        
                                    <select name='style_name'> 
             
                                <option value="Select">Select</option> 
                                <option value="Tassels">Tassels</option>  
                                <option value="Piping">Piping</option>  
                                <option value="latkan">latkan</option>  
                                     </select> 
                                    <br><br>
          </div>
          <div class="input-box">
            <span class="details">Lining Name</span>
            <select name='lining'> 
            <option value="Select">Select</option> 
                                <option value="cotton kurti">Cotton </option>  
                                <option value="crepe kurti">Crepe </option>  
                                <option value="silk kurti">Silk </option>  
                                <option value="rayon kurti">Rayon </option>
                                <option value="georgette kurti">Georgette </option>
                                     </select> 
                                  <br><br>
          </div>
          <div class="input-box">
            <span class="details">Delivery date</span>
            
            <input type="date" name="delivery_date" value="<?php echo isset($_POST['delivery_date']) ? htmlspecialchars($_POST['delivery_date'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details"> Dress Model</span>
            <input type="file"  name="image" value="<?php echo isset($_POST['file']) ? htmlspecialchars($_POST['file'],ENT_QUOTES): '';?>"> 
          </div>
          
		  <div class="new">
							<table>
								<tr>
									<td>
										<div class="reset">
											<input class="input" type=button value="Reset"
												onclick="this.form.reset();">
										</div>
									</td>
									
									<td>

										<div class="continue">
											<input class="input" id="submit" type=submit name=order
												value=order>
                                                

										</div>

									</td>
								
								</tr>
							</table>




						</div>


          <button type="submit" name="back"  style="align:right;">Go back!</button>

      </form>
    </div>
  </div>
    </section>

</body>
</html>