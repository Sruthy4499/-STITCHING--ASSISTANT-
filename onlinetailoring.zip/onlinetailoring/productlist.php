    <?php
include 'connection.php';
session_start();
$loginid = $_SESSION['loginid'];
if($_SESSION['loginid']==""){
  header('location:login.php');
}
$sql = mysqli_query($con,"SELECT * from register where loginid='$loginid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['name'];
  $pimg=$row["productimage"];
}
  


    

	?>
	

<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>.</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="img/vismaya.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="img/vismaya.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="csss/css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="csss/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="csss/css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="csss/css/custom.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

   
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                
                <!--<div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left: 718px;font-weight: 700;background-color: #d33b33;height: 44px; width: 159px;">
                    <i class="fa fa-user" aria-hidden="true" style="float: left; padding-left: 10px; padding-top: 4px;"></i>
                    <p class="app-sidebar__user-name"></i><?php echo $name; ?></p>
                    </button>
                      <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                         <li><a class="dropdown-item" href="my-account.php">View Profile</a></li>
                         <li><a class="dropdown-item" href="cart.php">View Cart</a></li>
                         <li><a class="dropdown-item" href="logout.php">Log Out</a></li>
                        
    
                      </ul>
                </div>-->
                   
                  
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="img/vismaya.png" class="logo" alt=""  style="height: 124px;width: 147px;"></a>
                    <div class="brand_name">
                    <h2 style="margin-top: 10px;font-family: 'Montserrat';font-weight: 600;">Vismaya<br>Products<h2>
                    
                    </div>

                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                       <!-- <li class="nav-item"><a class="nav-link" href="index.php">HOME</a></li>-->
                        <li class="nav-item active"><a class="nav-link" href="productlist.php">Shop</a></li>
                       <!-- <li class="dropdown">
                            <a class="nav-link dropdown" data-toggle="dropdown" style="margin-right: 17px;">PRODUCTS</a>
                            <ul class="dropdown-menu">
                                <li><a href="login.php">T-shirt</a></li>
                                <li><a href="login.php">Shirts</a></li>
                                <li><a href="login.php">Jeans</a></li>
                                <li><a href="login.php">Shorts</a></li>
                                <li><a href="login.php">Cargos</a></li>
                                <li><a href="login.php">Hoodies</a></li>
                            </ul>
                        </li>-->
                        <li class="nav-item"><a class="nav-link" href="my_account.php">My Account</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
               
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
            <div class="side">
            <a href="#" class="close-side"><i class="fa fa-times"></i></a>
                <li class="cart-box">
                    <ul class="cart-list">
                    <?php  
                            $result = mysqli_query($con,"SELECT tbl_cart.loginid,tbl_cart.price,tbl_cart.totalprice, tbl_cart.pro_id,tbl_products.product_name, tbl_products.product_image FROM tbl_cart LEFT JOIN tbl_products ON tbl_cart.cartid = tbl_products.pro_id where loginid='$loginid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                    
                        <li>
                            
                            <a href="#" class="photo"><img src="productimages/<?php echo $raw['pro_id']; ?>/<?php echo $raw['product_image']; ?>" class="cart-thumb" alt="" /></a>
                            <h6><a href="#"> <?php echo $raw['pname']; ?></a></h6>
                           
                            <p>1x - <span class="price"><?php echo $raw['price']; ?></span></p>
                        </li>
                        
                        <?php } ?>
                        
                       
                        <li class="total"> 
                          <a href="cart.php" class="btn btn-default hvr-hover btn-cart">VIEW CART</a>
                        </li>
                        
                        
                        	 
                    </ul>
                </li>
            </div>
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
    <div class="top-search">
        <div class="container">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" class="form-control" placeholder="Search">
                <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
            </div>
        </div>
    </div>
    

    

    <!-- Start Shop Page  -->
    <div class="shop-box-inner">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-sm-12 col-xs-12 sidebar-shop-left">
                    <div class="product-categori">
                       <!-- <div class="search-product">
                            <form action="" method="POST">
                                <input class="form-control" placeholder="Search here..." type="text">
                                <button type="submit"> <i class="fa fa-search"></i> </button>
                            </form>
                        </div>-->
                        <div class="filter-sidebar-left">
                            <div class="title-left">
                                <h3>Categories</h3>
                            </div>
                            <div class="list-group list-group-collapse list-group-sm list-group-tree" id="list-group-men" data-children=".sub-men">
                            <a class="nav-link active"  href="productlist.php?pro_id=1" role="tab" aria-controls="" aria-selected="true">Home</a>
                                <?php while ($row = mysqli_fetch_array($sql)){ ?>
						<a class="nav-link active" id="<?php echo $row['category_id']; ?>" href="proguctlist.php?pro_id=<?php echo $row['category_id']; ?>" role="tab" aria-controls="<?php echo $row['cid']; ?>" aria-selected="true"><?php echo $row['cname']; ?></a>
                        <?php } ?>
                            </div>
                        </div>
        
                        <div class="filter-brand-left ">
                            
                            <div class="brand-box">
                                
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-xl-9 col-lg-9 col-sm-12 col-xs-12 shop-content-right ">
                    <div class="right-product-box" >
                        <div class="product-item-filter row">
                            <div class="col-12 col-sm-8 text-center text-sm-left">
                               <!-- <div class="toolbar-sorter-right">
                                    <span>Sort by </span>
                                    <select id="basic" class="selectpicker show-tick form-control" data-placeholder="$ USD">
									<option data-display="Select">Nothing</option>
									<option value="1">Popularity</option>
									<option value="2">High Price → High Price</option>
									<option value="3">Low Price → High Price</option>
									<option value="4">Best Selling</option>
								</select>
                                </div>-->
                                
                            </div>
                            <!--<div class="col-12 col-sm-4 text-center text-sm-right">
                                <ul class="nav nav-tabs ml-auto">
                                    <li>
                                        <a class="nav-link active" href="#grid-view" data-toggle="tab"> <i class="fa fa-th"></i> </a>
                                    </li>
                                    <li>
                                        <a class="nav-link" href="#list-view" data-toggle="tab"> <i class="fa fa-list-ul"></i> </a>
                                    </li>
                                </ul>
                            </div>-->
                        </div>
                       

                        <div class="row product-categorie-box">
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade show active" id="grid-view">
                                    <div class="row">
                                    <?php 
                                    
                            $result = mysqli_query($con,"SELECT * FROM tbl_products where  status='active'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                                        <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                        <form method="post"  enctype="multipart/form-data" action="productlist.php<?php echo $sid; ?>">
                                            <div class="products-single fix">
                                                <div class="box-img-hover">
                                                
                                                <img src="productimages/<?php echo $pimg; ?>/<?php echo $raw['product_image']; ?>" class="img-fluid" alt="Image">
                                                   
                                                </div>
                                                <div class="why-text">
                                                    <h4><?php echo $raw['product_name']; ?></h4>
                                                    <h5><?php echo $raw['price']; ?></h5>
                                                    <input type="hidden" name="productid" value="<?php echo $raw['pro_id']; ?>"> 
                                                    <a class="nav-link" id="<?php echo $raw['pro_id']; ?>" href="listbox.php?sid=<?php echo $raw['pro_id']; ?>" role="tab" aria-controls="<?php echo $raw['pro_id']; ?>" aria-selected="true">View product</a>
                                                </div>
                                            </div>
                                            </form>
                                        </div>
                                        <?php }  ?>	
                                    </div>
                                </div>
                                
                                     
                             
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Shop Page -->

   

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js1/jquery-3.2.1.min.js"></script>
    <script src="js1/popper.min.js"></script>
    <script src="js1/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js1/jquery.superslides.min.js"></script>
    <script src="js1/bootstrap-select.js"></script>
    <script src="js1/inewsticker.js"></script>
    <script src="js1/bootsnav.js."></script>
    <script src="js1/images-loded.min.js"></script>
    <script src="js1/isotope.min.js"></script>
    <script src="js1/owl.carousel.min.js"></script>
    <script src="js1/baguetteBox.min.js"></script>
    <script src="js1/jquery-ui.js"></script>
    <script src="js1/jquery.nicescroll.min.js"></script>
    <script src="js1/form-validator.min.js"></script>
    <script src="js1/contact-form-script.js"></script>
    <script src="js1/custom.js"></script>
</body>

</html>