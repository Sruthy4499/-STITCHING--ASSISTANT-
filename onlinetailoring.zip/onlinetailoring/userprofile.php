<?php
session_start();
include "connection.php";

if(isset($_SESSION['loginid']))
{
 
$id=$_SESSION['loginid'];
$query="SELECT * FROM 'login' where loginid ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);

if($r[4]==1)
{

  $query1="SELECT * FROM 'register' where loginid ='$id'";
  $res1 = mysqli_query($con,$query1);
  $r1=mysqli_fetch_array($res1);



?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Vismaya</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <!-- Top Bar Start -->
        <div class="top-bar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <div class="logo">
                            <a href="admin_index.html">
                                <img src="img/vismaya.png" alt="Logo"> 
                            </a>
                        </div>
                    </div>
                            <div class="col-4">
                                <div class="top-bar-item">
                                    <div class="top-bar-icon">
                                        <i class="fa fa-phone-alt"></i>
                                    </div>
                                    <div class="top-bar-text">
                                        <h3>Call Us</h3>
                                        <p>+7306310207</p>
                                    </div>
                                </div>
                            </div>
                      </div>
                    </div>                                          
                </div>
            </div>
        </div>
        <!-- Top Bar End -->

<!-- Nav Bar Start -->
<div class="nav-bar">
            <div class="container">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <a href="user_index.php" class="nav-item nav-link active">Home</a>
                            <a href="userprofile.php" class="nav-item nav-link">User Profile</a> 
                            <ul>
                            <a href="measurment.php" class="nav-item nav-link">Measurment Size</a>
                            <a href="logout.php" class="nav-item nav-link">Logout</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Nav Bar End -->

          <div class="row mb-3">
          <?php 

$id=$_SESSION['log_id'];
$query5 ="SELECT * FROM 'register','login' WHERE 'login'.loginid ='$id' AND 'register'.loginid='login'.loginid";  
$res = mysqli_query($con,$query5);
$r=mysqli_fetch_array($res);
?>
<form action="userprofile.php" method="POST" name="frm" id="form" class="frm" >
<div class="error"><p id="demo"></p></div>
<table width="100%" border="3" style="border-collapse:collapse;">
<tr>
<th><center><strong> Name</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter The Name" name="name" id="name"autocomplete="off" value="<?php echo $r['name'];?>"></center>
<div class="error"><p id="demo1"></p></div>
</td>
</tr>
<tr>
<th><center><strong>Age</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter The Age" name="age" id="age"autocomplete="off" value="<?php echo $r['age'];?>"></center>
<div class="error"><p id="demo1"></p></div>
</td>
</tr>
<tr>
<th><center><strong>Address</strong></center></th>
<td class="tdi"><center><input type="text" class ="in" id="address" name="address" autocomplete="off" value="<?php echo $r['address'];?>"></center>
<div class="error"><p id="demo2"></p></div>
</td>
</tr>
<tr>
<th><center><strong>Email</strong></center></th>
<td class="tdi"><center><input type="text" class ="in" placeholder="Enter The email"id ="email" name="email"autocomplete="off" value="<?php echo $r['email'];?>"></center>
<div class="error"><p id="demo4"></p></div>
</td>
</tr> 
<tr>
<th><center><strong>Phone Number</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter The Phonenumber" name="phonenumber" id="phonenumber"autocomplete="off" value="<?php echo $r['phonenumber'];?>"></center>
<div class="error"><p id="demo1"></p></div>
</td>
</tr>
<tr>
<th><center><strong></strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter The Age" name="age" id="age"autocomplete="off" value="<?php echo $r['age'];?>"></center>
<div class="error"><p id="demo1"></p></div>
</td>
</tr>
</table>
<button type="submit" name="Click" class="button1">Update</button>
<a href="userprofile.php" class="button2">Cancel</a>

   </table>
</form>

          <!-- Modal Logout -->
          <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <p>Are you sure you want to logout?</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <a href="logout.php" class="btn btn-primary">Logout</a>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!---Container Fluid-->
      </div>
     
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
  <script src="vendor/chart.js/Chart.min.js"></script>
  <script src="js/demo/chart-area-demo.js"></script>  
</body>
</html>
<?php
if(isset($_POST["Click"]))
{
$name=$_POST['name'];
$age=$_POST['age'];
$address=$_POST['address'];
$email=$_POST['email'];
$phonenumber=$_POST['phonenumber'];
$sql2="UPDATE register SET name = '$name', age = '$age', address='$address' , email='$email', phonenumber='$phonenumber' WHERE loginid='$id'";
$result=mysqli_query($con,$sql2);
if($result)
{
  
    ?>
    <script>
    alert("Profile Updated Successfully");
    </script>
    <?php
    die('<script type="text/javascript">window.location.href="UserProfile.php"</script>');
  }
  
else{
?>
<script>
alert("Error Occured");
</script>
<?php
}
}?>
<?php
mysqli_close($con);			
?>