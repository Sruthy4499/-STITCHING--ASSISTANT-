<?php
require_once "connection.php";
if(isset($_POST['insert'])){

    $category=$_POST['category'];
    $product_name=$_POST['product_name'];
    $pdesc=$_POST['pdesc'];
    $price=$_POST['price'];
    $quantity=$_POST['quantity'];
    
    $filepath1=pathinfo($_FILES['product_image']['name']) ;
    $extension1=$filepath1['extension'];
    $rd=  rand();
    $aname= $rd.'.'.$extension1;
    $pathinfo='uploads/'.$aname;
    move_uploaded_file($_FILES['product_image']['tmp_name'],$pathinfo);
   

  
  $sql=mysqli_query($con,"INSERT INTO `tbl_products`(  `category`,`product_name`,`pdesc`,`price`,`quantity`,`product_image`,`status`)values('$category','$product_name','$pdesc','$price','$quantity',$aname,'active')") or die(mysqli_error($con));
  if($sql)
    echo "<script>alert('Inserted Successfully');</script>";
}
if(isset($_POST['back']))
{

  header('location:admin_index.php');
}
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Vismaya</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
    
    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style3.css" rel="stylesheet">
   
   
  </head>
  
    <section>
    <body background="img/bg.jpg">
  <div class="container">
    <div class="title"><b>ADD PRODUCTS<b></div>
    <br />
    <div class="content">
      <form action="" method="post" >
        <div class="user-details">
        <div class="input-box">
            <span class="details">category</span>
            
            
            
                                    <!--<div class="rs-select2 js-select-simple select--no-search">-->
                                        <select name="category" style="height:30px;width:170px;">
                                        <option value="">Select Category</option>
                                        <option value="">Kurti</option>
                                        <option value="">Gown</option>
                                        <option value="">Kids Section</option>
                                        <option value="">Blouse</option>
                                      
                                            <?php $query=mysqli_query($con,"select * from tbl_category");
                                          while($row=mysqli_fetch_array($query))
                                          {
                                            ?>

                                            <!-- <option value="<?php //echo $row['category_name'];?>"> -->
                                            </option>
                                            <?php } ?>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div> 
          </div>
          <div class="input-box">
            <span class="details">Product Name</span>
            <input type="text"  name="product_name" value="<?php echo isset($_POST['product_name']) ? htmlspecialchars($_POST['product_name'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">Description</span>
            
            <input type="text" name="pdesc" value="<?php echo isset($_POST['pdesc']) ? htmlspecialchars($_POST['pdesc'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Price</span>
            <input type="text"  name="price" value="<?php echo isset($_POST['price']) ? htmlspecialchars($_POST['price'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">Quantity</span>
            <input type="text"  name="quantity" value="<?php echo isset($_POST['quantity']) ? htmlspecialchars($_POST['quantity'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">Images</span>
            <input type="file"  name="product_image" value="<?php echo isset($_POST['product_image']) ? htmlspecialchars($_POST['product_image'],ENT_QUOTES): '';?>"> 
          </div>
          <input type="submit" name="insert" value="Insert" class="btn btn-primary" style="margin-left: 70%;">
          <button type="submit" name="back"  style="align:right;">Go back!</button>

      </form>
    </div>
  </div>
    </section>

</body>
</html>
