<?php
session_start();
$loginid=$_SESSION['loginid'];
include 'connection.php';
if(isset($_POST['insert'])){
  $loginid=$_SESSION['loginid'];
   
    $staff_name = $_POST['staff'];
    $description=$_POST['description'];
    $date = $_POST['date'];
    $amount=$_POST['amount'];
   
// $filepath=pathinfo($_FILES['file']['name']) ;
// $extension=$filepath['extension'];
    
// $iname= date('H-i-s').'.'.$extension;
// $path='img/'.$iname;
// move_uploaded_file($_FILES['file']['tmp_name'],$path);
  
  $sql=mysqli_query($con,"INSERT INTO `salary`( `loginid`,`description`, `date`, `amount`)
  values('$staff_name','$description','$date','$amount')") or die(mysqli_error($con));
  if($sql)
    echo "<script>alert('Inserted Successfully');</script>";
}
if(isset($_POST['back']))
{

  header('location:admin.php');
}
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Vismaya</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
    
    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style3.css" rel="stylesheet">
    
    
  </head>
  
    <section>
    <body background="img/bg.jpg">
  <div class="container">
    <div class="title"><b>Salary<b></div>
    <br />
    <div class="content">
      <form action="" method="post" enctype="multipart/form-data">
        <div class="user-details">
          
         
          <div class="">
            <span class="details">Staff Name</span>
            <select name='staff' class="details" id='staff' required>
              <option></option>
              <?php 
              $con=mysqli_connect('localhost','root','','vis');
              $query=mysqli_query($con,"select * from login where usertype='staff'");
              while($row=mysqli_fetch_array($query)){
                ?>
                <option value="<?php echo $row['loginid'];?>"><?php echo $row['username'];?></option>
                <?php 
              } 
              ?>
             </select>
            </div>
          <div class="input-box">
            <span class="details">Description</span>
            
            <input type="text" name="description" value="<?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description'],ENT_QUOTES): '';?>">  
          </div>
         
          <div class="input-box">
            <span class="details">Date</span>
            <input type="date" name="date" value="<?php echo isset($_POST['date']) ? htmlspecialchars($_POST['date'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">Amount</span>
            <input type="text" name="amount" value="<?php echo isset($_POST['amount']) ? htmlspecialchars($_POST['amount'],ENT_QUOTES): '';?>"> 
          </div>
          <input type="submit" name="insert" value="Insert" class="btn btn-primary" style="margin-left: 70%;">
          <button type="submit" name="back"  style="align:right;">Go back!</button>

      </form>
    </div>
  </div>
    </section>

</body>
</html>
