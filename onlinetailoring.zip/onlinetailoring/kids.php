<?php
require_once "connection.php";
if(isset($_POST['insert'])){

    
    $name = $_POST['name'];
    $code=$_POST['code'];
    $image=$_POST['image'];
    $price=$_POST['price'];
  
  $sql=mysqli_query($con,"INSERT INTO `kids` ( `name`, `code`, `image`, `price`)values('$name','$code','$image','$price')") or die(mysqli_error($con));
  if($sql)
    echo "<script>alert('Inserted Successfully');</script>";
}
if(isset($_POST['back']))
{

  header('location:admin_index.php');
}
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Vismaya</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
    
    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style3.css" rel="stylesheet">
   
   
  </head>
  
    <section>
    <body background="img/bg.jpg">
  <div class="container">
    <div class="title"><b>Kids<b></div>
    <br />
    <div class="content">
      <form action="" method="post" >
        <div class="user-details">
        <div class="input-box">
            <span class="details">Kids Dress Name</span>
            
            <input type="text" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Code</span>
            <input type="text"  name="code" value="<?php echo isset($_POST['code']) ? htmlspecialchars($_POST['code'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">Image</span>
            
            <input type="file" name="image" value="<?php echo isset($_POST['file']) ? htmlspecialchars($_POST['file'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Price</span>
            <input type="text"  name="price" value="<?php echo isset($_POST['price']) ? htmlspecialchars($_POST['price'],ENT_QUOTES): '';?>"> 
          </div>
          <input type="submit" name="insert" value="Insert" class="btn btn-primary" style="margin-left: 70%;">
          <button type="submit" name="back"  style="align:right;">Go back!</button>

      </form>
    </div>
  </div>
    </section>

</body>
</html>