<?php
session_start();
include 'connection.php';
if(isset($_SESSION['id']))
    $id=$_SESSION['id'];




$result=mysqli_query($con,"SELECT  `leave_type`,`day_type`,`date_start`,`date_end`,`days`,`reason`  FROM `leave_add` where id=$id") or die(mysqli_error($con));


include('pdf_mc_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'View Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);	
$pdf->Multicell(80,12,'leave_type : '. $row['leave_type'],1);
$pdf->Multicell(80,12,'day_type : '. $row['day_type'],1);
$pdf->Multicell(80,12,'date_start : '. $row['date_start'],1);
$pdf->Multicell(80,12,'date_end : '. $row['date_end'],1);
$pdf->Multicell(80,12,'days: '. $row['days'],1);
$pdf->Multicell(80,12,'reason : '. $row['reason'],1);
$pdf->Output();
?>