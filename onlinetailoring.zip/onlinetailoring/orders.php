<?php
session_start();
include 'connection.php';
$sql=mysqli_query($con,"SELECT * FROM `style` order by style_id ASC") or die(mysqli_error($con));

if(isset($_POST['viewdetails']))
{
    $style_id=$_POST['style_id'];
    $_SESSION['style_id']=$style_id;
    header('location:pdf.php');
}
?>

<html>
    <body background="img/bg.jpg">
    <form method="post">
    <h1 align="center">Orders List</h1>
        <table border="1">
            <tr>
                <th>Image</th>
                <th>Style</th>
                <th>lining</th>                 
                <th>Delivery date</th> 
                
               
            </tr>
            <?php 
                while($res=mysqli_fetch_array($sql))
                {
                ?>
                    <tr>
                        <td><img src="uploads/<?php echo $res['image']; ?>" width=70 height=70></td>                 
                        <td><?php echo $res['style_name'];?></td>
                        <td><?php echo $res['lining'];?></td>
                       <td><?php echo $res['delivery_date'];?></td>
                      
                      
                     
                         
                      <!--  <td>
                            <input type="hidden" name="kurti_id" value="<?php echo $res['gown_id'];?>">-->
                           <!-- <a href=pdf.php?kurtiid=<?php echo $res['gown_id'];?>><button type="submit" name="viewdetails">View Details</button></a>--></form></td>

                    </tr>
                
                <?php
                }
                ?>
        </table>
    </body>
</html>
