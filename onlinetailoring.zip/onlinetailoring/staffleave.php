<?php
require_once "connection.php";
if(isset($_POST['submit'])){

    
    
    $staff_name=$_POST['staff_name'];
    $email = $_POST['email'];
    $leave_type=$_POST['leave_type'];
    $reason=$_POST['reason']; 
    $start_date=$_POST['start_date']; 
    $end_date=$_POST['end_date'];
   

// $filepath=pathinfo($_FILES['file']['name']) ;
// $extension=$filepath['extension'];
    
// $iname= date('H-i-s').'.'.$extension;
// $path='img/'.$iname;
// move_uploaded_file($_FILES['file']['tmp_name'],$path);
  
  $sql=mysqli_query($con,"INSERT INTO `tbl_leave` (  `staff_name`, `email`,`leave_type`,`reason`,`start_date`,`end_date`,`is_approved`)values('$staff_name','$email','$leave_type','$reason','$start_date','$end_date','NO')") or die(mysqli_error($con));
  if($sql)
    echo "<script>alert('Inserted Successfully');</script>";
}
if(isset($_POST['back']))
{

  header('location:staff_index.php');
}
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Vismaya</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
    
    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style3.css" rel="stylesheet">
    
  
  </head>
  
    <section>
    <body background="img/bg.jpg">
  <div class="container">
    <div class="title"><b>Leave Apply <b></div>
    <br />
    <div class="content">
      <form action="" method="post" enctype="multipart/form-data">
        <div class="user-details">
        
          
          <div class="input-box">
            <span class="details">Staff Name</span>
            
            <input type="text" name="staff_name" value="<?php echo isset($_POST['staff_name']) ? htmlspecialchars($_POST['staff_name'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">email</span>
            <input type="text"  name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">Leave Type</span>
            <input type="text" name="leave_type" value="<?php echo isset($_POST['leave_type']) ? htmlspecialchars($_POST['leave_type'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">reason</span>
            <input type="text"  name="reason" value="<?php echo isset($_POST['reason']) ? htmlspecialchars($_POST['reason'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">start_date</span>
            <input type="date"  name="start_date" value="<?php echo isset($_POST['start_date']) ? htmlspecialchars($_POST['start_date'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">end_date</span>
            <input type="date"  name="end_date" value="<?php echo isset($_POST['end_date']) ? htmlspecialchars($_POST['end_date'],ENT_QUOTES): '';?>"> 
          </div>
          <input type="submit" name="submit" value="submit" class="btn btn-primary" style="margin-left: 70%;">
          <button type="submit" name="back"  style="align:right;">Go back!</button>

      </form>
    </div>
  </div>
    </section>

</body>
</html>
