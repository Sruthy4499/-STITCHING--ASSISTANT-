<?php
require_once "connection.php";
if(isset($_POST['insert'])){

    
    $title = $_POST['title'];
    $type=$_POST['type'];
    $description=$_POST['description'];

   
    $filepath1=pathinfo($_FILES['image']['name']) ;
    $extension1=$filepath1['extension'];
    $rd=  rand();
    $aname= $rd.'.'.$extension1;
    $pathinfo='uploads/'.$aname;
    move_uploaded_file($_FILES['image']['tmp_name'],$pathinfo);
// $filepath=pathinfo($_FILES['file']['name']) ;
// $extension=$filepath['extension'];
    
// $iname= date('H-i-s').'.'.$extension;
// $path='img/'.$iname;
// move_uploaded_file($_FILES['file']['tmp_name'],$path);
  
  $sql=mysqli_query($con,"INSERT INTO `part`( `title`, `type`, `description`, `image`)values('$title','$type','$description','$aname')") or die(mysqli_error($con));
  if($sql)
    echo "<script>alert('Inserted Successfully');</script>";
}
if(isset($_POST['back']))
{

  header('location:admin_index.php');
}
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Vismaya</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
    
    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style3.css" rel="stylesheet">
    
    
    <script>
    var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".gif", ".png"];    
    function ValidateSingleInput(oInput) {
      if (oInput.type == "file") {
          var sFileName = oInput.value;
          if (sFileName.length > 0) {
              var blnValid = false;
              for (var j = 0; j < _validFileExtensions.length; j++) {
                  var sCurExtension = _validFileExtensions[j];
                  if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                      blnValid = true;
                      break;
                  }
              }
              
              if (!blnValid) {
                  alert("Sorry, file is invalid, allowed extensions are: " + _validFileExtensions.join(", "));
                  oInput.value = "";
                  return false;
              }
          }
      }
      return true;
    }

	

    </script>
  </head>
  
    <section>
    <body background="img/bg.jpg">
  <div class="container">
    <div class="title"><b>Add Parts<b></div>
    <br />
    <div class="content">
      <form action="" method="post" enctype="multipart/form-data">
        <div class="user-details">
             
          <div class="input-box">
            <span class="details">Title</span>
            
            <input type="text" name="title" value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Type</span>
            
            <input type="text" name="type" value="<?php echo isset($_POST['type']) ? htmlspecialchars($_POST['type'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Description</span>
            <input type="text" name="description" value="<?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">Image</span>
            <input type="file"  name="image" value="<?php echo isset($_POST['file']) ? htmlspecialchars($_POST['file'],ENT_QUOTES): '';?>"> 
          </div>
         
          <input type="submit" name="insert" value="Insert" class="btn btn-primary" style="margin-left: 70%;">
          <button type="submit" name="back"  style="align:right;">Go back!</button>

      </form>
    </div>
  </div>
    </section>

</body>
</html>
