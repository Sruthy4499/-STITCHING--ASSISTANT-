<?php
include 'connection.php';
session_start();

if(isset($_POST['submit1'])){
  $username=$_POST['username'];
  $password=$_POST['password'];

  $sql="SELECT * FROM login where username ='$username' and password = '$password'";
  $result =mysqli_query($con,$sql);
  if($result)
  {
    while($row=mysqli_fetch_assoc($result)){
      $loginid=$row['loginid'];
  if($row['usertype']=="admin")
  {
    $_SESSION['loginid']=$loginid;
    ?>
  <script type="text/Javascript">  
    window.location.href="admin.php";
   </script>
   <?php     
  }
  else if($row['usertype']=="user")
  {
    $_SESSION['loginid']=$loginid;
    
    
    ?>
  <script type="text/Javascript">  
    window.location.href="user_index.php";
   </script> 
    <?php     
  }else if($row['usertype']=="staff"){
    $_SESSION['loginid']=$loginid;
    
    ?>
    <script type="text/Javascript">  
    window.location.href="staff_index.php";
   </script> 
   <?php     
  }else if($row['usertype']=="seller"){
    $_SESSION['loginid']=$loginid;
    
    ?>
    <script type="text/Javascript">  
    window.location.href="seller_index.php";
   </script>
    <?php
  }
  else
{
  echo '<script>alert("Invalid Username or Pasword")</script>';
  
}
}
  }
}


?>




<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login Form </title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
<div id="login-form-wrap">
  <h2>Login</h2>
  <form id="login-form" method="post" action="">
    <p>
    <input type="text" id="username" name="username" placeholder="Username" required><i class="validation"><span></span><span></span></i>
    </p>
    <p>
    <input type="password" id="password" name="password" placeholder="password" required><i class="validation"><span></span><span></span></i>
    </p>
    <p>
    <input type="submit" id="login" name="submit1" value="Login">
    </p>
  </form>
  <div id="create-account-wrap">
    <p>Not a member? <a href="register1.php">Create Account</a><p>
  </div>
</div>
  
</body>
</html>