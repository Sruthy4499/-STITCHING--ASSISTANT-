
<?php
require_once "connection.php";
if(isset($_POST['insert'])){

    
    $Neck= $_POST['Neck'];
    $Chest=$_POST['Chest'];
    $Waist = $_POST['Waist'];
    $SleeveLength=$_POST['SleeveLength'];
    $Hips= $_POST['Hips'];
    $Shoulder=$_POST['Shoulder'];
    $Armhole = $_POST['Armhole'];
    
   
    

  $sql=mysqli_query($con,"INSERT INTO `measurement` ( `Neck`, `Chest`, `Waist`, `SleeveLength`,`Hips`, `Shoulder`, `Armhole`)values('$Neck','$Chest','$Waist','$SleeveLength','$Hips','$Shoulder','$Armhole')") or die(mysqli_error($con));
  if($sql)
    echo "<script>alert('Inserted Successfully');</script>";
}
if(isset($_POST['back']))
{

  header('location:admin_index.php');
}
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Vismaya</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
    
    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style3.css" rel="stylesheet">

  </head>
  
    <section>
    <body background="img/bg.jpg">
  <div class="container">
    <div class="title"><b>Measurment( in inches)<b></div>
    <br />
    <div class="content">
      <form action="" method="post" enctype="multipart/form-data">
        <div class="user-details">
        <div class="input-box">
            <span class="details">Neck</span>
            
            <input type="text" name="Neck" value="<?php echo isset($_POST['Neck']) ? htmlspecialchars($_POST['Neck'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Chest</span>
            <input type="text" name="Chest" value="<?php echo isset($_POST['Chest']) ? htmlspecialchars($_POST['Chest'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Waist</span>
            <input type="text" name="Waist" value="<?php echo isset($_POST['Waist']) ? htmlspecialchars($_POST['Waist'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">SleeveLength</span>
            <input type="text" name="SleeveLength" value="<?php echo isset($_POST['SleeveLength']) ? htmlspecialchars($_POST['SleeveLength'],ENT_QUOTES): '';?>"> 
          </div>
          <div class="input-box">
            <span class="details">Hips</span>
            <input type="text" name="Hips" value="<?php echo isset($_POST['Hips']) ? htmlspecialchars($_POST['Hips'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Shoulder</span>
            <input type="text" name="Shoulder" value="<?php echo isset($_POST['Shoulder']) ? htmlspecialchars($_POST['Shoulder'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Armhole</span>
            <input type="text" name="Armhole" value="<?php echo isset($_POST['Armhole']) ? htmlspecialchars($_POST['Armhole'],ENT_QUOTES): '';?>">  
          </div>
          <input type="submit" name="insert" value="Insert" class="btn btn-primary" style="margin-left: 70%;">
          <button type="submit" name="back"  style="align:right;">Go back!</button>

      </form>
    </div>
  </div>
    </section>

</body>
</html>
