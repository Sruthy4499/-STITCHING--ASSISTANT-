<?php
include 'connection.php';
if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $date_of_birth=$_POST['date_of_birth'];
  $address=$_POST['address'];
  $email=$_POST['email'];
  $phonenumber=$_POST['phonenumber'];
  $username=$_POST['username'];
  $password=$_POST['password'];
  $Designation=$_POST['Designation'];
  $duty=$_POST['duty'];
  $salary=$_POST['salary'];

  

  $sql=mysqli_query($con,"INSERT INTO `login`(`username`, `password`, `usertype`)values('$username','$password','seller')");
  $loginid=mysqli_insert_id($con);
  echo $loginid;
  $sql=mysqli_query($con,"INSERT INTO `register`(`loginid`, `name`, `date_of_birth`, `address`, `email`, `phonenumber`, `Designation`, `duty`, `salary`) VALUES('$loginid','$name','$date_of_birth','$address','$email','$phonenumber','$Designation','$duty','$salary')");
  header('Location: login.php');
  
}
  
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
   
    <style>
        body 
    {
        margin:0;
      padding:0;
      background:url("img/imag.png");
      -webkit-background-size:cover;
      background-size:cover;
      background-position:center;
      font-family:sans-serif;
       
        }
       
        .body-content {
            padding-top: 10vh;
        }
       
        .container {
            width: 500px;
            height: 700px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin: auto;
            border: 0px;
            border-radius: 15px;
            background:white;
      box-shadow:8px 8px 50px #000;
      
        }
       
        .logo {
            margin-bottom: 0px;
            margin-top: 0px;
            padding-top: 0;
        }
       
        .logo img {
            width: 100px;
            margin: 10px;
            border-radius: 10px;
        }
       
        .form {
            display: flex;
            flex-direction: column;
        }
       
        .form-item {
            margin: 5px;
            padding-bottom: 10px;
            display: flex;
        }
       
        .form-item label {
            display: block;
            padding: 2px;
            font-size: 20px;
            width: 100px;
        }
       
        .form-item input {
            width: 320px;
            height: 35px;
            border: 2px solid #e1dede69;
            border-radius: 20px;
            background:#e1dede69;
            
        }
       
        .form-btns {
            display: flex;
            flex-direction: column;
            margin: auto;
            padding: 10px 0;
      
        }
       
        .form-btns button {
            margin: auto;
            font-size: 20px;
            padding: 5px 15px;
            border: 2px solid;
            border-radius: 15px;
            background:black;
            width: 280px;
            cursor: pointer;
      color:white;
        }
    
    .form-btns button:hover
    {
      cursor: pointer;
      background:#b0b435;
      color:#000;
    }
       
        .options {
            padding-top: 15px;
            margin: auto;
        }
       
        .options a {
            text-decoration: none;
            color: black;
            margin: 0 40px;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 20px;

        }
        .options a:hover {
            color: black;
 
        }
       
        p {
            text-align: center;
            font-size: 10px;
            font-family: Arial, Helvetica, sans-serif;
        }
       
    </style>

<script>
  function registration()
      {
  
          var name= document.getElementById("t1").value;
          var date_of_birth= document.getElementById("t2").value;
          var address= document.getElementById("t3").value;
          var email= document.getElementById("t4").value;
          var phonenumber= document.getElementById("t5").value;
          var Designation=document.getElementById("t6").value;
          var duty=document.getElementById("t7").value;
          var salary=document.getElementById("t8").value;
          var username= document.getElementById("t9").value;
          var password= document.getElementById("t10").value;     
          var cpwd= document.getElementById("t11").value
         
          
         
          var password_expression = /^(?=.?[A-Z])(?=.?[a-z])(?=.?[0-9])(?=.?[#?!@$%^&*-])/;
          var letters = /^[A-Za-z]+$/;
          var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
          var phonenumber = /^\d{10}$/;
          
      if(name=='')
           {
              alert('Please enter your name');
          }
          else if(!letters.test(name))
          {
              alert('Name field required only alphabet characters');
          }
          else if(=='date_of_birth')
          {
              alert('Please enter your user DOB');
          }
          else if (!date_of_birth.test(date_of_birth))
          {
              alert('Enter the DOB format correctly');
          }
          else if(address=='')
          {
              alert('Please enter your user address');
          }
          else if (!letters.test(address))
          {
              alert('Enter the address format correctly');
          }
     
          else if(email=='')
          {
              alert('Please enter your user email id');
          }
          else if (!filter.test(email))
          {
              alert('Enter the e-mail format correctly');
          }
      else if(phonenumber=='')
          {
              alert('Please enter your number');
          }
      else if(!phonenumber.test(number))
          {
              alert('Enter number correctly');
          }
          else if(Designation=='')
          {
              alert('Please enter your Designation');
          }
      else if(!Designation.test(Designation))
          {
              alert('Enter Designation correctly');
          }
          else if(=='duty')
          {
              alert('Please enter your Duty ');
          }
      else if(!Designation.test(duty))
          {
              alert('Enter Duty correctly');
          }
          else if(salary=='')
          {
              alert('Please enter your salary');
          }
      else if(!salary.test(salary))
          {
              alert('Enter salary correctly');
          }
          else if(username=='')
          {
              alert('Please enter the user name.');
          }
          else if(!letters.test(username))
          {
              alert('User name field required only alphabet characters');
          }
          else if(password=='')
          {
              alert('Please enter Password');
          }
          else if(cpwd=='')
          {
              alert('Enter Confirm Password');
          }
          else if(!password_expression.test(password))
          {
              alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
          }
          else if(password != cpwd)
          {
              alert ('Password not Matched');
          }
          else if(document.getElementById("t5").value.length < 6)
          {
              alert ('Password minimum length is 6');
          }
          else if(document.getElementById("t5").value.length > 12)
          {
              alert ('Password max length is 12');
          }
          else
          {                                   
                 alert('Successfully Registered');
               
          }
      }
      </script>

</head>

<body>
    <div class="body-content">

        <div class="container">
            <div class="logo">
                <img src="img\vismaya.png" alt="vismaya logo" srcset="">
            </div>
            <div class="login-form">

                <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-item">
                        <input type="text" name="name" id="name" placeholder="Enter your name" required onchange="Validate();">
                        <span id="msg1" style="color:red;"></span>
                        <script>		
function Validate() 
{
    var val = document.getElementById('name').value;

    if (!val.match(/^[A-Z][A-Za-z\ ]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('name').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
                    </div>
                    <div class="form-item">
                        <input type="date" name="date_of_birth" id="date_of_birth" placeholder="Enter your Date-of-Birth" required onchange="ValidateDOB();">
                        <span id="msg2" style="color:red;"></span>
                        <script>
function ValidateDOB() {
        var lblError = document.getElementById("lblError");
 
        //Get the date from the TextBox.
        var dateString = document.getElementById("txtDate").value;
        var regex = /(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$/;
 
        //Check whether valid dd/MM/yyyy Date Format.
        if (regex.test(dateString)) {
            var parts = dateString.split("/");
            var dtDOB = new Date(parts[1] + "/" + parts[0] + "/" + parts[2]);
            var dtCurrent = new Date();
            lblError.innerHTML = "Eligibility 18 years ONLY."
            if (dtCurrent.getFullYear() - dtDOB.getFullYear() < 18) {
                return false;
            }
 
            if (dtCurrent.getFullYear() - dtDOB.getFullYear() == 18) {
 
                //CD: 11/06/2018 and DB: 15/07/2000. Will turned 18 on 15/07/2018.
                if (dtCurrent.getMonth() < dtDOB.getMonth()) {
                    return false;
                }
                if (dtCurrent.getMonth() == dtDOB.getMonth()) {
                    //CD: 11/06/2018 and DB: 15/06/2000. Will turned 18 on 15/06/2018.
                    if (dtCurrent.getDate() < dtDOB.getDate()) {
                        return false;
                    }
                }
            }
            lblError.innerHTML = "";
            return true;
        } else {
            lblError.innerHTML = "Enter date in dd/MM/yyyy format ONLY."
            return false;
        }
    }
</script>
</div> 

                                 <div class="form-item">
                        <input type="text" name="address" id="address" placeholder="Enter your address" required onchange="Validadd();" >
                        <span id="msg3" style="color:red;"></span>
                        <script>		
function Validadd() 
{
    var val = document.getElementById('address').value;

    if (!val.match(/^[A-Z][a-z" "]{3,}$/)) 
    {
        document.getElementById('msg3').innerHTML="Start with a Capital letter & Only alphabets are allowed";
		            document.getElementById('address').value = "";
        return false;
    }
document.getElementById('msg3').innerHTML=" ";
    return true;
}
</script>
                    </div>
          <div class="form-item">
                        <input type="text" name="email" id="email" placeholder="Enter your email" required onchange="Validata();">
                        <span id="msg4" style="color:red;"></span>
                        <script>		
function Validata() 
{
    var val = document.getElementById('email').value;

    if (!val.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) 
    {
        document.getElementById('msg4').innerHTML="Enter a Valid Email";
		
		     document.getElementById('email').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}

		</script>
                    </div>
                    <div class="form-item">
                        <input type="number" name="phonenumber" id="phonenumber" placeholder="Enter your Phone Number" required onchange="Validno();">
                        <span id="msg5" style="color:red;"></span>
                        <script>
function Validno() 
{
    var val = document.getElementById('phonenumber').value;

    if (!val.match(/^[789][1-9]{9}$/))
    {
        document.getElementById('msg5').innerHTML="Only Numbers are allowed and must contain number";
	
		
		            document.getElementById('age').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}
</script>

                    </div>
                    <div class="form-item">
                        <input type="text" name="Designation" id="Designation" placeholder="Enter your Designation" required onchange="Validaten();">
                        <span id="msg6" style="color:red;"></span>
                        <script>		
function Validaten() 
{
    var val = document.getElementById('Designation').value;

    if (!val.match(/^[A-Z][A-Za-z\ ]{3,}$/)) 
    {
        document.getElementById('msg6').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('Designation').value = "";
        return false;
    }
document.getElementById('msg6').innerHTML=" ";
    return true;
}
</script>
                    </div>
                    <div class="form-item">
                        <input type="text" name="duty" id="duty" placeholder="Enter your Duty" required onchange="Validatio();">
                        <span id="msg7" style="color:red;"></span>
                        <script>		
function Validatio() 
{
    var val = document.getElementById('duty').value;

    if (!val.match(/^[A-Z][A-Za-z\ ]{3,}$/)) 
    {
        document.getElementById('msg7').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('duty').value = "";
        return false;
    }
document.getElementById('msg7').innerHTML=" ";
    return true;
}
</script>
                    </div>
                    
                    <div class="form-item">
                        <input type="number" name="salary" id="salary" placeholder="Enter your salary" required onchange="Validsa();">
                        <span id="msg8" style="color:red;"></span>
                        <script>
function Validsa() 
{
    var val = document.getElementById('salary').value;

    if (!val.match(/^\d{1,6}(?:\.\d{0,2})?$/))
    {
        document.getElementById('msg8').innerHTML="Only Numbers are allowed and must contain 5 number";
	
		
		            document.getElementById('salary').value = "";
        return false;
    }
document.getElementById('msg8').innerHTML=" ";
    return true;
}

</script>
                    </div>
                    <div class="form-item">
                        <input type="text" name="username" id="username" placeholder="Enter your username" required onchange="Validuname();">
                        <span id="msg9" style="color:red;"></span>
                        <script>		
function Validuname() 
{
    var val = document.getElementById('username').value;

    if (!val.match(/^[A-Z][A-Za-z\ ]{3,}$/)) 
    {
        document.getElementById('msg9').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('username').value = "";
        return false;
    }
document.getElementById('msg9').innerHTML=" ";
    return true;
}
</script>
                    </div>
                    <div class="form-item">
                       
                        <input type="password" name="password" id="password" placeholder="Enter Password" required onchange="Validp();"  >
                        <span id="msg10" style="color:red;"></span>
                        <script>		
function Validp() 
{
    var val = document.getElementById('password').value;

    if (!val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/)) 
    {
        document.getElementById('msg10').innerHTML="Upper case, Lower case, Special character and Numeric number are required in Password filed";
		
		     document.getElementById('password').value = "";
        return false;
    }
document.getElementById('msg10').innerHTML=" ";
    return true;
}

</script>

                    </div>
          <div class="form-item">
                        <input type="password" name="cpwd" id="cpwd" placeholder="Confirm Password" required onchange="check();">
                        <span id="msg11" style="color:red;"></span>

                        <script>
function check()
{
var pas1=document.getElementById("cpwd");
							  var pas2=document.getElementById("confirm_password");
							
							  if(pas1.value=="")
	{
		document.getElementById('msg11').innerHTML="Password can't be null!!";
		pas1.focus();
		return false;
	}
	if(pas2.value=="")
	{
		document.getElementById('msg11').innerHTML="Please confirm password!!";
		pass2.focus();
		return false;
	}
	if(pas1.value!=pas2.value)
	{
		document.getElementById('msg11').innerHTML="Passwords does not match!!";
		pas1.focus();
		return false;
	}
     document.getElementById('msg11').innerHTML=" "; 
	return true;
	
}
 </script>                  
  </div>

                    <div class="form-btns">

                        <button type="submit" name="submit" onClick="registration()" >Register</button>
                        <div class="options">
                           <a href="index.php">Home</a>
               
                            
                        </div>
                    </div>

                </form>     
            </div>
        </div>
    </div>
</body>
</html>
