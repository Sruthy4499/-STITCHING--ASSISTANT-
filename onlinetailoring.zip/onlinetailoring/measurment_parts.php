<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Vismaya</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <!-- Top Bar Start -->
        <div class="top-bar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <div class="logo">
                            <a href="admin_index.html">
                                <img src="img/vismaya.png" alt="Logo"> 
                            </a>
                        </div>
                    </div>
                            <div class="col-4">
                                <div class="top-bar-item">
                                    <div class="top-bar-icon">
                                        <i class="fa fa-phone-alt"></i>
                                    </div>
                                    <div class="top-bar-text">
                                        <h3>Call Us</h3>
                                        <p>+7306310207</p>
                                    </div>
                                </div>
                            </div>
                      </div>
                    </div>                                          
                </div>
            </div>
        </div>
        <!-- Top Bar End -->

<!-- Nav Bar Start -->
<div class="nav-bar">
            <div class="container">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <a href="admin.php" class="nav-item nav-link active">Home</a>
                            <a href="customerdetails.php" class="nav-item nav-link">Customer Details</a> 
                           
                            <a href="addcloth.php" class="nav-item nav-link">Add Cloths</a>
                            <a href="logout.php" class="nav-item nav-link">Logout</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Nav Bar End -->
<?php
session_start();
include 'connection.php';


$sql=mysqli_query($con,"SELECT * FROM `part`  order by part_id ASC") or die(mysqli_error($con));

if(isset($_POST['viewdetails']))
{
    $part_id=$_POST['part_id'];
    $_SESSION['part_id']=$part_id;
    header('location:measurment_parts.php');
}
if(isset($_POST['back']))
{

  header('location:admin_index.php');
}
?>


    <body background="img/bg.jpg">
    <button type="submit" name="back"  style="align:right;">Go back!</button>
 
    <h1 align="center">Measurment parts</h1>
        <table border="1">
            <tr>
               
                <th> title</th>
                <th>type</th>                
                <th>description</th>
                <th>Image</th>
                
               
            </tr>
            <?php 
                while($res=mysqli_fetch_array($sql))
                {
                ?>
                    <tr>
                                     
                        <td><?php echo $res['title'];?></td>
                        <td><?php echo $res['type'];?></td>
                        <td><?php echo $res['description'];?></td>
                        <td><img src="uploads/<?php echo $res['image']; ?>" width=70 height=70></td>  
                        <form method="post">
                            <input type="hidden" name="part_id" value="<?php echo $res['part_id'];?>">
    
                            
                    </tr>
                
                <?php
                }
                ?>
        </table>
    </body>
</html>
