<?php
include 'connection.php';
if(isset($_GET['order_id']))
{
    $id=$_GET['order_id'];
    $sql = "DELETE FROM order WHERE order_id=$id";
    $result = mysqli_query($con, $sql);
    if($result)
    {
      header('location:order.php');
    }
    else{
        echo "no!";
    }
    }

?>