<html>
    <head>
        <title>Search</title>
</head>
<body>
<section class=search>
                        <form action=/ method=GET>
                            <input type=text placeholder='Search the blog...' name=search>
                            <button type=submit class=button>Search</button>
                        </form>
                    </section>
</body>
</html>