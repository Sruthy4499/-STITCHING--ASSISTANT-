-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2022 at 08:11 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vismaya`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `loginid` int(20) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `usertype` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`loginid`, `username`, `password`, `usertype`) VALUES
(1, 'hello', 'hello', 0),
(2, 'hello', 'hello@', 0),
(3, 'hello', 'hello@', 0),
(4, 'green', 'green@', 0),
(5, 'maya', 'maya@', 0),
(6, 'greenk', 'greenkk', 0),
(7, 'greenk', '', 0),
(8, 'greenk', '', 0),
(9, 'greenk', '', 0),
(10, 'mahi', 'mahi', 0),
(11, 'yellow', 'yellow@', 0),
(12, 'abc', 'abc@', 0);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `rid` int(100) NOT NULL,
  `loginid` int(100) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `age` int(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phonenumber` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`rid`, `loginid`, `fname`, `age`, `address`, `email`, `phonenumber`, `image`) VALUES
(2, 6, 'green', 22, 'juiko', 'green@gmail.com', 2147483647, 'imag.PNG'),
(3, 7, 'green', 22, 'juiko', 'green@gmail.com', 2147483647, 'imag.PNG'),
(4, 8, 'green', 22, 'juiko', 'green', 2147483647, 'imag.PNG'),
(5, 9, 'green', 22, 'juiko', 'green', 2147483647, 'imag.PNG'),
(6, 10, 'maya', 22, 'jkljlklk', 'may', 1234567898, 'img2.jpg'),
(7, 11, 'yellow', 55, 'yellowhouse', 'yellow', 2147483647, 'img1.jpg'),
(8, 12, 'abc', 22, 'gfhgh', 'abc@gmail.com', 2147483647, 'A2.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`loginid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `loginid` (`loginid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `loginid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `rid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `register`
--
ALTER TABLE `register`
  ADD CONSTRAINT `register_ibfk_1` FOREIGN KEY (`loginid`) REFERENCES `login` (`loginid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
