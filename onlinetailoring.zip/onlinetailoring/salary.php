<?php
session_start();
include 'connection.php';
$sql=mysqli_query($con,"SELECT * FROM `salary` order by salary_id ASC") or die(mysqli_error($con));

if(isset($_POST['update']))
{
    $salary_id=$_POST['salary_id'];
    $_SESSION['salary_id']=$employee_id;
    
}
if(isset($_POST['update']))
{
    $designation_id=$_GET['salary_id'];
    $_SESSION['salary_id']=$salary_id;
    header('location:salaryedit.php');
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Vismaya</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

   
    
        <!-- Top Bar Start -->
        <div class="top-bar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <div class="logo">
                            <a href="index.html">
                                <img src="img/vismaya.png" alt="Logo"> 
                            </a>
                        </div>
                    </div>
                            <div class="col-4">
                                <div class="top-bar-item">
                                    <div class="top-bar-icon">
                                        <i class="fa fa-phone-alt"></i>
                                    </div>
                                    <div class="top-bar-text">
                                        <h3>Call Us</h3>
                                        <p>+7306310207</p>
                                    </div>
                                </div>
                            </div>
                            
                      </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Top Bar End -->

        <!-- Nav Bar Start -->
       
        <div class="nav-bar">
            <div class="container">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                           <a href="admin_index.php" class="nav-item nav-link active">Home</a>
                            
                            <a href="logout.php" class="nav-item nav-link">Logout</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Nav Bar End -->
    
    <h1 align="center">Salary List</h1>
    <div  class="panel"><div class="table-responsive"><table class="table table-striped title1">
    <tr>
      <td><b>Employee Id</b></td>
      <td><b>Description</b></td>
      <td><b>Date</b></td>
      <td><b>Amount</b></td>
      <td><b>Action</b></td>
    </tr>
        
            <?php 
                while($res=mysqli_fetch_array($sql))
                {
                ?>
                    <tr>
                                      
                        <td><?php echo $res['loginid'];?></td>
                        <td><?php echo $res['description'];?></td>
                       <td><?php echo $res['date'];?></td>
                       <td><?php echo $res['amount'];?></td>

                       <td width=300><form method="post">
                       
                       <input type="hidden" name="salary_id" value="<?php echo $res['salary_id'];?>">
                       <button type="submit" name="update">UPDATE</button></form></td>
                      <!--  <td>
                            <input type="hidden" name="kurti_id" value="<?php echo $res['gown_id'];?>">-->
                           <!-- <a href=pdf.php?kurtiid=<?php echo $res['gown_id'];?>><button type="submit" name="viewdetails">View Details</button></a>--></form></td>
                           
                    </tr>
                
                <?php
                }
                ?>
        </table>
    </body>
</html>
