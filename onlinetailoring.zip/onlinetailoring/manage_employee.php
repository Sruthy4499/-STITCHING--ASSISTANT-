<?php
session_start();
$loginid=$_SESSION['loginid'];
include 'connection.php';
if(isset($_POST['insert'])){

    $name=$_POST['name'];
    $date_of_birth=$_POST['date_of_birth'];
    $address=$_POST['address'];
    $email=$_POST['email'];
    $phonenumber=$_POST['phonenumber'];
    $Designation=$_POST['Designation'];  
    $duty=$_POST['duty'];
    
    

    $filepath1=pathinfo($_FILES['image']['name']) ;
    $extension1=$filepath1['extension'];
    $rd=  rand();
    $aname= $rd.'.'.$extension1;
    $pathinfo='uploads/'.$aname;
    move_uploaded_file($_FILES['image']['tmp_name'],$pathinfo);
   

  
  $sql=mysqli_query($con,"INSERT INTO `register`( `loginid`,`date_of_birth`, `address`, `email`, `phonenumber`, `Designation`, `duty`,`image`) VALUES ('$name','$date_of_birth','$address','$email','$phonenumber','$Designation','$duty','$aname')") or die(mysqli_error($con));
  if($sql)
    echo "<script>alert('Inserted Successfully');</script>";
}
if(isset($_POST['back']))
{

  header('location:admin.php');
}
?>
<!--<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Vismaya</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

       
        <link href="img/favicon.ico" rel="icon">

       
        <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
        
        
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
       
        <div class="top-bar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <div class="logo">
                            <a href="index.html">
                                <h1>Vis<span>maya</span></h1>
                               
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-7 d-none d-lg-block">
                        <div class="row">
                            <div class="col-4">
                                <div class="top-bar-item">
                                    <div class="top-bar-icon">
                                        <i class="fa fa-phone-alt"></i>
                                    </div>
                                    <div class="top-bar-text">
                                        <h3>Call Us</h3>
                                        <p>+91 7306310207</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="nav-bar">
            <div class="container">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <a href="admin.php" class="nav-item nav-link active">Home</a>
                            <a href="about.php" class="nav-item nav-link">About</a>
                            <a href="services.php" class="nav-item nav-link">Service</a>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>
                        
                            <a href="logout.php" class="nav-item nav-link">Logout</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        
        
 Template Stylesheet -->
 <link href="css/style3.css" rel="stylesheet">
    <script>
    var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".gif", ".png"];    
    function ValidateSingleInput(oInput) {
      if (oInput.type == "file") {
          var sFileName = oInput.value;
          if (sFileName.length > 0) {
              var blnValid = false;
              for (var j = 0; j < _validFileExtensions.length; j++) {
                  var sCurExtension = _validFileExtensions[j];
                  if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                      blnValid = true;
                      break;
                  }
              }
              
              if (!blnValid) {
                  alert("Sorry, file is invalid, allowed extensions are: " + _validFileExtensions.join(", "));
                  oInput.value = "";
                  return false;
              }
          }
      }
      return true;
    }

    </script>
  </head>
  
    <section>
    <body background="img/bg.jpg">
  <div class="container">
    <div class="title"><b>Add Staff<b></div>
    <br />
    <div class="content">
      <form action="" method="post" enctype="multipart/form-data">
        <div class="user-details">
          <div class="input-box">
            <span class="details"> Name</span>
            
            <input type="text" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">DOB</span>
            
            <input type="date" name="date_of_birth" value="<?php echo isset($_POST['date_of_birth']) ? htmlspecialchars($_POST['date_of_birth'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Address</span>
            
            <input type="text" name="address" value="<?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            
            <input type="text" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
            <span class="details">Contact</span>
            
            <input type="text" name="phonenumber" value="<?php echo isset($_POST['phonenumber']) ? htmlspecialchars($_POST['phonenumber'],ENT_QUOTES): '';?>">  
          </div>
          <div class="input-box">
							<label for="designation">Designation</label>
							<select name="Designation" id="Designation" class="form-control select2bs4 select2 rounded-0" data-placeholder="Please Select Designation here" reqiured>
								<option value="" disabled selected></option>
																	<option value="Stitiching Staff" >Stitiching Staff</option>
																	<option value="Designer" >Designer</option>
																	<option value="Seller" >Seller</option>
																	
															</select>
						</div>
          <div class="input-box">
            <span class="details">Duty</span>
            
            <input type="text" name="duty" value="<?php echo isset($_POST['duty']) ? htmlspecialchars($_POST['duty'],ENT_QUOTES): '';?>">  
          </div>
               
          <div class="input-box">
            <span class="details">Image</span>
            
            <input type="file" name="image" value="<?php echo isset($_POST['image']) ? htmlspecialchars($_POST['image'],ENT_QUOTES): '';?>">  
          </div>
          <input type="submit" name="insert" value="Insert" class="btn btn-primary" style="margin-left: 70%;">
          <button type="submit" name="back"  style="align:right;">Go back!</button>

      </form>
    </div>
  </div>
    </section>

</body>
</html>

        