<?php
session_start();
// error_reporting(0);
include('connection.php');
	if(isset($_POST['update']))
	{
		$loginid=$_POST['loginid'];
		$description=$_POST['description'];
		$date=$_POST['date'];
		$amount=$_POST['amount'];
		
		$query=mysqli_query($con,"update salary set loginid='$loginid',description='$description',date='$date',amount='$amount' where employee_id='".$_SESSION['employee_id']."'");
		if($query)
		{
echo "<script>alert('Your info has been updated');</script>";
		}
	}
      
   ?>
   
   <!DOCTYPE html>  
  <html>  
  <head>  
  <meta name="viewport" content="width=device-width, initial-scale=1">  
  <style>  
  body {
    background:linear-gradient(to right, #78a7ba 0%, #385D6C 50%, #78a7ba 99%);
  }
  .container {  
      padding: 100px;  
    background-color: white;  
  }  
    
  input[type=text], input[type=password], textarea {  
    width: 100%;  
    padding: 15px;  
    margin: 5px 0 22px 0;  
    display: inline-block;  
    border: none;  
    background: #f1f1f1;  
  }  
  input[type=text]:focus, input[type=password]:focus {  
    background-color: gray;  
    outline: none;  
  }  
   div {  
              padding: 10px 0;  
           }  
  hr {  
    border: 1px solid #f1f1f1;  
    margin-bottom: 25px;  
  }  
  .registerbtn {  
    background-color: #4CAF50;  
    color: white;  
    padding: 16px 20px;  
    margin: 8px 0;  
    border: none;  
    cursor: pointer;  
    width: 100%;  
    opacity: 0.9;  
  }  
  .registerbtn:hover {  
    opacity: 1;  
  } 
   
  .button {
    border: none;
    color: white;
    padding: 10px 25px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
  
  }
  
  .button1 {background-color: #4CAF50;} /* Green */
  .button2 {background-color: #008CBA;} 
  </style> 
  <style> form{
    padding: 100px 550px;
  }</style> 
  </head>
  <?php
  $salary_id=$_SESSION['salary_id'];
  ?>  
  <body>  
    
  <form method='post' action="" >  
    
    <div class="container">  
    <center>  <h1>UPDATE HERE</h1> </center>  
    <hr>  
    <div class="modal-header">
   
                            </div>
                        <div class="modal-body">
                       <div class="card-body card-block">
                       <div class="form-group">
                          <label for="company" class=" form-control-label">Employee Id :</label>
                     <input type="text"   class="form-control" name="loginid"  id="loginid"  onfocusout="f1()" value=<?php echo $loginid?> >
                  </div>
                  <div class="form-group">
                          <label for="company" class=" form-control-label">Description :</label>
                     <input type="text"   class="form-control" name="description"  id="description"  onfocusout="f1()" value=<?php echo $description?>
                  </div>
                  <div class="form-group">
                          <label for="company" class=" form-control-label">Date:</label>
                      <input type="text"  class="form-control" name="date" id="date"  onfocusout="f1()" value=<?php echo $date?>>
                  </div>
                  <div class="form-group">
                          <label for="company" class=" form-control-label">Amount :</label>
                     <input type="text"   class="form-control" name="amount"  id="amount"  onfocusout="f1()" value=<?php echo $amount?> >
                  </div>
                  
                       
                  </div>
              <div class="modal-footer">
              <button type="submit" class="button button1" name="update">Update</button>
                  <button type="button" class="button button2" data-dismiss="modal" style="margin-right: 66%"><a href="index.php">Cancel</a></button>
                     
              </div>
                     
              </div>
                  </div>
              
  </form>  
  </body>  
  </html> 
