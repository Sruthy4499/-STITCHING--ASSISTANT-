<?php
session_start();
// error_reporting(0);
include('connection.php');
	if(isset($_POST['update']))
	{
		$name=$_POST['name'];
		$date_of_birth=$_POST['date_of_birth'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$phonenumber=$_POST['phonenumber'];
        $Designation=$_POST['Designation'];
        $duty=$_POST['duty'];
		$query=mysqli_query($con,"update register set name='$name',date_of_birth='$date_of_birth',address='$address',email='$email',phonenumber='$phonenumber',Designation='$Designation',duty='$duty' where loginid='".$_SESSION['loginid']."'");
		if($query)
		{
echo "<script>alert('Your info has been updated');</script>";
		}
	}


date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () );

								
if(isset($_POST['submit']))
{

extract($_POST);
$cpass=$_POST["cpass"];
$newpass=$_POST["newpass"];
include 'connection.php';
$rs = mysqli_query($con,"SELECT * FROM login WHERE status='0' and usertype='staff' " );
			$row1=mysqli_fetch_assoc($rs);
        	$logid=$row1['loginid'];
	$sql="update login set password='$newpass' where loginid=$logid";
	$res3=mysqli_query($con,$sql);
	if($res3>0)
{
echo "<script>
window.onload=function()
{
alert('successfully  updated your password.....!');
window.location='profile.php';
}
</script>";
}
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Vismaya</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <!-- Top Bar Start -->
        <div class="top-bar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <div class="logo">
                            <a href="index.html">
                                <h1>Vis<span>maya</span></h1>
                                <!-- <img src="img/logo.jpg" alt="Logo"> -->
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-7 d-none d-lg-block">
                        <div class="row">
                            <div class="col-4">
                                <div class="top-bar-item">
                                    <div class="top-bar-icon">
                                        <i class="fa fa-phone-alt"></i>
                                    </div>
                                    <div class="top-bar-text">
                                        <h3>Call Us</h3>
                                        <p>+91 7306310207</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Top Bar End -->

        <!-- Nav Bar Start -->
        <div class="nav-bar">
            <div class="container">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <a href="staff_index.php" class="nav-item nav-link active">Home</a>
                            
                            <a href="logout.php" class="nav-item nav-link">Logout</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
		<!-- Meta -->
		<meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
		<meta name="description" content="">
		<meta name="author" content="">
	    <meta name="keywords" content="MediaCenter, Template, eCommerce">
	    <meta name="robots" content="all">

	    <title>My Account</title>

	    <!-- Bootstrap Core CSS -->
	    <link rel="stylesheet" href="assets1/css/bootstrap.min.css">
	    
	    <!-- Customizable CSS -->
	    <link rel="stylesheet" href="assets1/css/main.css">
	    <link rel="stylesheet" href="assets1/css/green.css">
	    <link rel="stylesheet" href="assets1/css/owl.carousel.css">
		<link rel="stylesheet" href="assets1/css/owl.transitions.css">
		<!--<link rel="stylesheet" href="assets/css/owl.theme.css">-->
		<link href="assets1/css/lightbox.css" rel="stylesheet">
		<link rel="stylesheet" href="assets1/css/animate.min.css">
		<link rel="stylesheet" href="assets1/css/rateit.css">
		<link rel="stylesheet" href="assets1/css/bootstrap-select.min.css">

		<!-- Demo Purpose Only. Should be removed in production -->
		<link rel="stylesheet" href="assets1/css/config.css">

		<link href="assets1/css/green.css" rel="alternate stylesheet" title="Green color">
		<link href="assets1/css/blue.css" rel="alternate stylesheet" title="Blue color">
		<link href="assets1/css/red.css" rel="alternate stylesheet" title="Red color">
		<link href="assets1/css/orange.css" rel="alternate stylesheet" title="Orange color">
		<link href="assets1/css/dark-green.css" rel="alternate stylesheet" title="Darkgreen color">
		<link rel="stylesheet" href="assets1/css/font-awesome.min.css">
		<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
		<link rel="shortcut icon" href="">
<script type="text/javascript">
function valid()
{
if(document.chngpwd.cpass.value=="")
{
alert("Current Password Filed is Empty !!");
document.chngpwd.cpass.focus();
return false;
}
else if(document.chngpwd.newpass.value=="")
{
alert("New Password Filed is Empty !!");
document.chngpwd.newpass.focus();
return false;
}
else if(document.chngpwd.cpwd.value=="")
{
alert("Confirm Password Filed is Empty !!");
document.chngpwd.cpwd.focus();
return false;
}
else if(document.chngpwd.newpass.value!= document.chngpwd.cpwd.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.chngpwd.cpwd.focus();
return false;
}
return true;
}
</script>

	</head>
    <body class="cnt-home">
<header class="header-style-1">

	<!-- ============================================== TOP MENU ============================================== -->

<!-- ============================================== TOP MENU : END ============================================== -->

	<!-- ============================================== NAVBAR ============================================== -->

<!-- ============================================== NAVBAR : END ============================================== -->

</header>
<!-- ============================================== HEADER : END ============================================== -->
<!--<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="#">Home</a></li>
				<li class='active'>Checkout</li>
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content outer-top-bd">
	<div class="container">
		<div class="checkout-box inner-bottom-sm">
			<div class="row">
				<div class="col-md-8">
					<div class="panel-group checkout-steps" id="accordion">
						<!-- checkout-step-01  -->
<div class="panel panel-default checkout-step-01">

	<!-- panel-heading -->
		<div class="panel-heading">
    	<h4 class="unicase-checkout-title">
	        <a data-toggle="collapse" class="" data-parent="#accordion" href="#collapseOne">
	          My Profile
	        </a>
	     </h4>
    </div>
    <!-- panel-heading -->

	<div id="collapseOne" class="panel-collapse collapse in">

		<!-- panel-body  -->
	    <div class="panel-body">
			<div class="row">		
<h4>Personal info</h4>
				<div class="col-md-12 col-sm-12 already-registered-login">

<?php
$query=mysqli_query($con,"select * from register where loginid='".$_SESSION['loginid']."'");
while($row=mysqli_fetch_array($query))
{
?>

					<form class="register-form" role="form" method="post">
<div class="form-group">
					    <label class="info-title" for="name">Name<span>*</span></label>
					    <input type="text" class="form-control unicase-form-control text-input" value="<?php echo $row['name'];?>" id="name" name="name" required="required" required onchange="Validate();">
						<span id="msg1" style="color:red;"></span>
						<script>		
function Validate() 
{
    var val = document.getElementById('name').value;

    if (!val.match(/^[A-Z][A-Za-z\ ]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('name').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
					  </div>


					  <div class="form-item">
					  <label class="info-title" for="name">DOB<span>*</span></label>
					  <input type="text" class="form-control unicase-form-control text-input" value="<?php echo $row['date_of_birth'];?>" id="date_of_birth" name="date_of_birth" required="required" required onchange="ValidateDOB();">
                        <span id="msg2" style="color:red;"></span>
                        <script>
							function ValidateDOB() {
        var lblError = document.getElementById("lblError");
 
        //Get the date from the TextBox.
        var dateString = document.getElementById("txtDate").value;
        var regex = /(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$/;
 
        //Check whether valid dd/MM/yyyy Date Format.
        if (regex.test(dateString)) {
            var parts = dateString.split("/");
            var dtDOB = new Date(parts[1] + "/" + parts[0] + "/" + parts[2]);
            var dtCurrent = new Date();
            lblError.innerHTML = "Eligibility 18 years ONLY."
            if (dtCurrent.getFullYear() - dtDOB.getFullYear() < 18) {
                return false;
            }
 
            if (dtCurrent.getFullYear() - dtDOB.getFullYear() == 18) {
 
                //CD: 11/06/2018 and DB: 15/07/2000. Will turned 18 on 15/07/2018.
                if (dtCurrent.getMonth() < dtDOB.getMonth()) {
                    return false;
                }
                if (dtCurrent.getMonth() == dtDOB.getMonth()) {
                    //CD: 11/06/2018 and DB: 15/06/2000. Will turned 18 on 15/06/2018.
                    if (dtCurrent.getDate() < dtDOB.getDate()) {
                        return false;
                    }
                }
            }
            lblError.innerHTML = "";
            return true;
        } else {
            lblError.innerHTML = "Enter date in dd/MM/yyyy format ONLY."
            return false;
        }
    }
</script>
</div>

                                 <div class="form-item">
								 <label class="info-title" for="name">Address<span>*</span></label>
								 <input type="text" class="form-control unicase-form-control text-input" value="<?php echo $row['address'];?>" id="address" name="address" required="required" required onchange="Validadd();">
                        <span id="msg3" style="color:red;"></span>
                        <script>		
function Validadd() 
{
    var val = document.getElementById('address').value;

    if (!val.match(/^[A-Z][a-z" "]{3,}$/)) 
    {
        document.getElementById('msg3').innerHTML="Start with a Capital letter & Only alphabets are allowed";
		            document.getElementById('address').value = "";
        return false;
    }
document.getElementById('msg3').innerHTML=" ";
    return true;
}
</script>
                    </div>
         
                    <div class="form-item">
					<label class="info-title" for="name">Phone Number<span>*</span></label><br>
                        <input type="text" name="phonenumber" id="phonenumber" value="<?php echo $row['phonenumber'];?>" placeholder="Enter your Phone Number" required onchange="Validno();">
                        <span id="msg5" style="color:red;"></span>
                        <script>
function Validno() 
{
    var val = document.getElementById('phonenumber').value;

    if (!val.match(/^[789][1-9]{9}$/))
    {
        document.getElementById('msg5').innerHTML="Only Numbers are allowed and must contain number";
	
		
		            document.getElementById('phonenumber').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}
</script>

                    </div>
                    
						<div class="form-group">
					    <label class="info-title" for="exampleInputEmail1">Email Address <span>*</span></label>
			 <input type="email" name="email" class="form-control unicase-form-control text-input" id="email" value="<?php echo $row['email'];?>" required onchange="Validata();">
			           <span id="msg5" style="color:red;"></span>
<script>		
function Validata() 
{
    var val = document.getElementById('email').value;

    if (!val.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) 
    {
        document.getElementById('msg5').innerHTML="Enter a Valid Email";
		
		     document.getElementById('email').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

		</script>
					<!-- </div>
					  <div class="form-group">
					    <label class="info-title" for="Contact No.">Contact No. <span>*</span></label>
					    <input type="text" class="form-control unicase-form-control text-input" id="phone" name="phone" required="required" value="<?php echo $row['phone'];?>"  maxlength="10" required onchange="Validat();">
						<span id="msg4" style="color:red;"></span>
			
<script>
function Validat() 
{
    var val = document.getElementById('phone').value;

    if (!val.match(/^[789][1-9]{9}$/))
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed and must contain 10 number";
	
		
		            document.getElementById('phone').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}

</script>-->
					  </div>
					  <div class="form-group">
					    <label class="info-title" for="">Designation<span>*</span></label>
					    <input type="text" class="form-control unicase-form-control text-input" id="Designation" name="Designation" required="required" value="<?php echo $row['Designation'];?>"  maxlength="10" required onchange="Validdesi();">
						<span id="msg0" style="color:red;"></span>
<script>		
function Validdesi() 
{
    var val = document.getElementById('Designation').value;

    if (!val.match(/^[A-Z][a-z" "]{3,}$/)) 
    {
        document.getElementById('msg0').innerHTML="Start with a Capital letter & Only alphabets are allowed";
		            document.getElementById('Designation').value = "";
        return false;
    }
document.getElementById('msg0').innerHTML=" ";
    return true;
}
</script>

					  </div>
                    
					  
<div class="form-group">
					    <label class="info-title" for="">Duty<span>*</span></label>
					    <input type="text" class="form-control unicase-form-control text-input" id="duty" name="duty" required="required" value="<?php echo $row['duty'];?>"  maxlength="10" required onchange="Validduty();">
						<span id="msg12" style="color:red;"></span>
<script>		
function Validduty() 
{
    var val = document.getElementById('duty').value;

    if (!val.match(/^[A-Z][a-z" "]{3,}$/)) 
    {
        document.getElementById('msg12').innerHTML="Start with a Capital letter & Only alphabets are allowed";
		            document.getElementById('duty').value = "";
        return false;
    }
document.getElementById('msg12').innerHTML=" ";
    return true;
}
</script>
</div>
					  <button type="submit" name="update" class="btn-upper btn btn-primary checkout-page-button">Update</button>
					</form>
					<?php } ?>
				</div>	
				<!-- already-registered-login -->		

			</div>			
		</div>
		<!-- panel-body  -->

	</div><!-- row -->
</div>

<!-- checkout-step-01  -->
					    <!-- checkout-step-02  -->
					  	<div class="panel panel-default checkout-step-02">
						    <div class="panel-heading">
						      <h4 class="unicase-checkout-title">
						        <a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseTwo">
						          Change Password
						        </a>
						      </h4>
						    </div>
						    <div id="collapseTwo" class="panel-collapse collapse">
						      <div class="panel-body">
						     
					<form class="register-form" role="form" method="post" name="chngpwd" onSubmit="return valid();">
<div class="form-group">
					    <label class="info-title" for="Current Password">Current Password<span>*</span></label>
					    <input type="password" class="form-control unicase-form-control text-input" id="cpass" name="cpass" required="required">
					  </div>



						<div class="form-group">
					    <label class="info-title" for="New Password">New Password <span>*</span></label>
			 <input type="password" class="form-control unicase-form-control text-input" id="newpass" name="newpass">
					  </div>
					  <div class="form-group">
					    <label class="info-title" for="Confirm Password">Confirm Password <span>*</span></label>
					    <input type="password" class="form-control unicase-form-control text-input" id="cpwd" name="cpwd" required="required" >
					  </div>
					  <button type="submit" name="submit" class="btn-upper btn btn-primary checkout-page-button">Change </button>
					</form> 




						      </div>
						    </div>
					  	</div>
					  	<!-- checkout-step-02  -->
					  	
					</div><!-- /.checkout-steps -->
				</div>
			
			</div><!-- /.row -->
		</div><!-- /.checkout-box -->
	

</div>
</div>

	<script src="assets1/js/jquery-1.11.1.min.js"></script>
	
	<script src="assets1/js/bootstrap.min.js"></script>
	
	<script src="assets1/js/bootstrap-hover-dropdown.min.js"></script>
	<script src="assets1/js/owl.carousel.min.js"></script>
	
	<script src="assets1/js/echo.min.js"></script>
	<script src="assets1/js/jquery.easing-1.3.min.js"></script>
	<script src="assets1/js/bootstrap-slider.min.js"></script>
    <script src="assets1/js/jquery.rateit.min.js"></script>
    <script type="text/javascript" src="assets1/js/lightbox.min.js"></script>
    <script src="assets1/js/bootstrap-select.min.js"></script>
    <script src="assets1/js/wow.min.js"></script>
	<script src="assets1/js/scripts.js"></script>

	<!-- For demo purposes – can be removed on production -->
	
	<script src="switchstylesheet/switchstylesheet.js"></script>
	
	<script>
		$(document).ready(function(){ 
			$(".changecolor").switchstylesheet( { seperator:"color"} );
			$('.show-theme-options').click(function(){
				$(this).parent().toggleClass('open');
				return false;
			});
		});

		$(window).bind("load", function() {
		   $('.show-theme-options').delay(2000).trigger('click');
		});
	</script>
</body>
</html>
<?php  ?>